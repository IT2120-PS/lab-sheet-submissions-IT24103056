setwd("C:\\Users\\it24103056\\Desktop\\it24103056 lab04")

branch_data <- read.table("Exercise.txt", header = TRUE, sep = "\t")

str(branch_data)  
summary(branch_data)  

boxplot(branch_data$Sales, main = "Boxplot of Sales", ylab = "Sales")

summary(branch_data$Advertising)
IQR(branch_data$Advertising)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


outliers_years <- find_outliers(branch_data$Years)
outliers_years

