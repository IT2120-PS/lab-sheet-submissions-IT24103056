setwd("C:\\Users\\nirgn\\OneDrive\\Desktop\\it24103056 lab 6")
getwd()
##binomal distribution
## Random variable x has binomal distribution with n=50 and p=0.85
1-pbinom(46,50,0.85,lower.tail = TRUE)

##X=number of calls in one hour
##poisson distribution
## Random variable x has poisson distribution with  lambda=12
dpois(15,12)
